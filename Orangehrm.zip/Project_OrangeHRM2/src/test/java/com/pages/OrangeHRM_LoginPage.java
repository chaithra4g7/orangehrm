package com.pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class OrangeHRM_LoginPage {
	
	WebDriver driver;
	@FindBy(name="txtUsername")
	WebElement Username;
	@FindBy(name="txtPassword")
	WebElement Password;
	@FindBy(name="Submit")
	WebElement LoginBtn;
	@FindBy(id="welcome")
	WebElement welcome;
	@FindBy(xpath="//a[text()='Logout']")
	WebElement logout;
	
	public OrangeHRM_LoginPage(WebDriver driver) {
		this.driver=driver;
	  PageFactory.initElements(driver,this);
	}
	
	public void DetailsEntry1(String un, String pw)
	{
		Username.sendKeys(un);
		Password.sendKeys(pw);
		}
	public void DetailsEntry()
		{
			Username.sendKeys("Admin");
			Password.sendKeys("admin123");
			}
		public void ClickLogin()
		{
			LoginBtn.click();
		}	
		public void Logout()
		{
			welcome.click();
			logout.click();
		}
}


